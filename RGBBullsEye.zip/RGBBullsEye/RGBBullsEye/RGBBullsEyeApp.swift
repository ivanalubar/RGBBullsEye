//
//  RGBBullsEyeApp.swift
//  RGBBullsEye
//
//  Created by Ivana Lubar on 15.06.21.
//

import SwiftUI

@main
struct RGBBullsEyeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView(rGuess: 0.5, gGuess: 0.5, bGuess: 0.5)
        }
    }
}
